#pragma once
// Mahalliy UI — embedded HTML sahifa (server.cpp orqali ko'rsatiladi)
inline const char* UI_HTML = R"HTML(<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SDrive Cluster — Boshqaruv</title>
<style>
:root{--bg:#0b0f17;--card:#151d2e;--line:#22304a;--txt:#e5e9f0;--dim:#8b97ad;--acc:#38bdf8;--ok:#22c55e;--warn:#f59e0b;--bad:#ef4444}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--txt);font-family:Segoe UI,system-ui,sans-serif;line-height:1.6;padding:24px}
.container{max-width:760px;margin:0 auto}
h1{font-size:22px;margin-bottom:4px}h1 b{color:var(--acc)}
.sub{color:var(--dim);font-size:13px;margin-bottom:20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:22px;margin-bottom:16px}
h2{font-size:16px;margin-bottom:12px}
label{display:block;color:var(--dim);font-size:13px;margin:10px 0 4px}
input,select{width:100%;background:#0e1526;border:1px solid var(--line);color:var(--txt);border-radius:8px;padding:10px;font-size:14px}
button{margin-top:16px;width:100%;padding:12px;border:none;border-radius:10px;font-weight:700;font-size:15px;cursor:pointer;background:var(--acc);color:#04121a}
button.ghost{background:transparent;border:1px solid var(--line);color:var(--txt)}
button.danger{background:var(--bad);color:#fff}
button:disabled{opacity:.5;cursor:not-allowed}
.row{display:flex;gap:10px}.row>*{flex:1}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px;text-align:center}
.stat b{display:block;font-size:20px;color:var(--acc)}
.stat span{color:var(--dim);font-size:12px}
.agree{max-height:320px;overflow-y:auto;background:#0e1526;border:1px solid var(--line);border-radius:10px;padding:14px;font-size:12px;white-space:pre-wrap;color:#c3cbd9}
.pill{display:inline-block;padding:3px 12px;border-radius:20px;font-size:12px;font-weight:700}
.pill.ok{background:rgba(34,197,94,.15);color:var(--ok)}.pill.off{background:rgba(245,158,11,.15);color:var(--warn)}
.note{color:var(--dim);font-size:12px;margin-top:8px}
.hidden{display:none}
#msg{font-size:13px;margin-top:10px}
</style>
</head>
<body>
<div class="container">
<h1>⬡ SDrive <b>Cluster</b></h1>
<div class="sub" id="nodeInfo"></div>

<div id="pageSetup" class="hidden">
  <div class="card">
    <h2>1. SDrive diskini sozlash</h2>
    <p class="sub">Sayt uchun qaysi diskdan qancha bo'sh joy ajratmoqchisiz? Shu o'lcham bo'yicha yangi SDrive diski yaratiladi.</p>
    <label>Disk harfi (Windows)</label>
    <select id="driveLetter"><option>S</option><option>D</option><option>E</option><option>F</option><option>G</option><option>H</option><option>I</option><option>J</option><option>K</option><option>L</option><option>M</option><option>N</option><option>O</option><option>P</option><option>Q</option><option>R</option><option>T</option><option>U</option><option>V</option><option>W</option><option>X</option><option>Y</option><option>Z</option></select>
    <label>Bo'sh joy hajmi (GB)</label>
    <input type="number" id="quotaGb" value="50" min="1" max="2000">
    <label>Saqlash papkasi</label>
    <input type="text" id="sdrivePath" placeholder="">
    <button onclick="doSetup()">SDrive diskini yaratish</button>
    <div id="msg"></div>
  </div>
</div>

<div id="pageAgree" class="hidden">
  <div class="card">
    <h2>2. Foydalanuvchi shartnomasi</h2>
    <div class="agree" id="agreeText">Yuklanmoqda...</div>
    <button onclick="acceptAgreement()">ROZIMAN — shartnomani qabul qilaman</button>
    <p class="note">Rozilik bildirmasangiz dastur hech qanday ma'lumot saqlamaydi.</p>
    <div id="msg2"></div>
  </div>
</div>

<div id="pageRun" class="hidden">
  <div class="card">
    <h2>Status <span id="statusPill" class="pill off">Oflayn</span></h2>
    <div class="stats">
      <div class="stat"><b id="stSpace">–</b><span>Band / Umumiy</span></div>
      <div class="stat"><b id="stTasks">–</b><span>Navbatdagi vazifalar</span></div>
      <div class="stat"><b id="stEarn">–</b><span>Daromad (sent)</span></div>
      <div class="stat"><b id="stUp">–</b><span>Tasdiqlangan vaqt</span></div>
    </div>
    <p class="sub">Dastur fon rejimida ishlaydi. Siz ishlayotgan paytda yuklamalar maksimal kamaytiriladi.</p>
    <button class="ghost" onclick="claimPayout()">Cash chiqarish (oy oxiri)</button>
    <button class="danger" onclick="doUninstall()">Dasturni o'chirish</button>
    <div id="msg3"></div>
  </div>
</div>

</div>
<script>
const $=s=>document.querySelector(s);
function show(p){['pageSetup','pageAgree','pageRun'].forEach(x=>$('#'+x).classList.add('hidden'));$('#'+p).classList.remove('hidden')}
async function j(method,url,body){const r=await fetch(url,{method,headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});return r.json()}

async function status(){
  const s=await j('GET','/api/status');
  $('nodeInfo').textContent='Node: '+s.nodeId+' · Server: '+s.serverUrl;
  if(!s.setupDone){show('pageSetup');$('sdrivePath').value=s.sdriveDir;return}
  if(!s.agreementAccepted){show('pageAgree');if(!window._agree){j('GET','/api/agreement').then(a=>{$('agreeText').textContent=a.text});window._agree=true}return}
  show('pageRun');
  $('stSpace').textContent=s.spaceUsedMB+' / '+s.quotaGB+' GB';
  $('stTasks').textContent=s.tasksDue;
  $('stEarn').textContent=s.earningsCents.toFixed(3);
  $('stUp').textContent=Math.floor(s.uptimeSec/3600)+' soat';
  const p=$('statusPill');p.textContent=s.online?'Onlayn':'Oflayn';p.className='pill '+(s.online?'ok':'off');
}
async function doSetup(){
  $('msg').textContent='';
  const r=await j('POST','/api/setup',{driveLetter:$('driveLetter').value,quotaGb:parseFloat($('quotaGb').value),sdriveDir:$('sdrivePath').value});
  if(r.ok){status()}else{$('msg').textContent='Xato: '+r.error}
}
async function acceptAgreement(){
  const r=await j('POST','/api/accept');if(r.ok)status();
}
async function claimPayout(){
  const r=await j('POST','/api/claim');
  $('msg3').textContent=r.ok?('Payout rasmiylashtirildi: $'+(r.amountCents/100).toFixed(2)+(r.forfeited?' (yo\'qotilgan — hisob o\'chirilgan)':'')):('Xato: '+r.error);
}
async function doUninstall(){
  if(!confirm('Diqqat! Oylik pulni oy oxirida chiqarib olmasangiz, hisob uchun pul to\'lanmaydi (shartnoma 6.2-band). Davom etasizmi?'))return;
  const r=await j('POST','/api/uninstall');
  $('msg3').textContent=r.ok?'Dastur o\'chirildi. SDrive diskidagi ma\'lumotlar olib tashlanmadi.':'Xato: '+r.error;
}
status();setInterval(status,5000);
</script>
</body>
</html>)HTML";
