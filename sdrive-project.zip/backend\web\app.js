const $ = s => document.querySelector(s);
const fmtB = b => b >= 1<<30 ? (b/(1<<30)).toFixed(2)+' GB' : b >= 1<<20 ? (b/(1<<20)).toFixed(1)+' MB' : (b/1024).toFixed(0)+' KB';
const fmtT = ts => ts ? new Date(ts*1000).toLocaleString() : '–';
const fmt$ = c => '$' + (c/100).toFixed(2);

async function loadInfo(){
  const d = await (await fetch('/api/info')).json();
  $('#stats').innerHTML = `
    <div class="stat"><span class="stat-num">${d.onlineNodes} / ${d.totalNodes}</span><span>Onlayn kompyuter</span></div>
    <div class="stat"><span class="stat-num">${fmtB(d.totalSpace)}</span><span>Jami berilgan xotira</span></div>
    <div class="stat"><span class="stat-num">${fmtB(d.storedBytes)}</span><span>Saqlangan ma'lumot</span></div>
    <div class="stat"><span class="stat-num">${d.totalFiles}</span><span>Fayllar</span></div>
    <div class="stat"><span class="stat-num">${d.doneReplicas}</span><span>Bajarilgan replikatsiya</span></div>
    <div class="stat"><span class="stat-num">${d.pendingTasks}</span><span>Kutilayotgan vazifa</span></div>
    <div class="stat"><span class="stat-num">${fmt$(d.paidCents)}</span><span>To'langan jami</span></div>`;
}

async function loadDash(){
  const d = await (await fetch('/api/dashboard')).json();

  $('#tNodes').innerHTML = `<tr><th>ID</th><th>Nom</th><th>OS</th><th>Status</th><th>Xotira</th><th>Tasdiqlangan vaqt</th><th>Daromad</th><th>Qo'shilgan</th></tr>` +
    d.nodes.map(n=>`<tr>
      <td class="mono">${n.id}</td><td>${n.name||'–'}</td><td>${n.os} / ${n.platform||'–'}</td>
      <td><span class="pill ${n.status==='uninstalled'?'r':n.online?'g':'y'}">${n.status==='uninstalled'?'O'chirilgan':n.online?'Onlayn':'Oflayn'}</span></td>
      <td>${fmtB(n.spaceUsed)} / ${fmtB(n.spaceTotal)}</td>
      <td>${Math.floor(n.verifiedUptimeSec/3600)} soat</td>
      <td>${fmt$(n.earningsCents)}</td>
      <td>${fmtT(n.joinedAt)}</td></tr>`).join('');

  $('#tFiles').innerHTML = `<tr><th>ID</th><th>Nomi</th><th>Hajmi</th><th>Chunks</th><th>Replikatsiya</th><th>Status</th><th>Yuklangan</th></tr>` +
    d.files.map(f=>`<tr>
      <td class="mono">${f.id}</td><td>${f.name}</td><td>${fmtB(f.size)}</td><td>${f.chunks.length}</td>
      <td>${f.replicasDone} / ${f.replicaTarget}</td>
      <td><span class="pill ${f.status==='degraded'?'y':'g'}">${f.status==='degraded'?'Degraded':'Aktiv'}</span></td>
      <td>${fmtT(f.uploadedAt)}</td></tr>`).join('');

  $('#tTasks').innerHTML = `<tr><th>ID</th><th>Node</th><th>Fayl</th><th>Tur</th><th>Status</th><th>Tayinlangan</th></tr>` +
    d.tasks.map(t=>`<tr>
      <td class="mono">${t.id}</td><td class="mono">${t.nodeId}</td><td class="mono">${t.fileId}</td>
      <td><span class="pill ${t.kind==='repair'?'b':'b'}">${t.kind}</span></td>
      <td><span class="pill ${t.status==='done'?'g':t.status==='failed'?'r':'y'}">${t.status}</span></td>
      <td>${fmtT(t.assignedAt)}</td></tr>`).join('');

  $('#tPayouts').innerHTML = `<tr><th>ID</th><th>Node</th><th>Davr</th><th>Summa</th><th>Status</th><th>Sana</th></tr>` +
    d.payouts.map(p=>`<tr>
      <td class="mono">${p.id}</td><td class="mono">${p.nodeId}</td><td>${p.period}</td>
      <td>${fmt$(p.amountCents)}</td>
      <td><span class="pill ${p.status==='paid'?'g':'r'}">${p.status==='paid'?'To'langan':'Yo'qotilgan'}</span></td>
      <td>${fmtT(p.createdAt)}</td></tr>`).join('');
}

loadInfo(); loadDash();
setInterval(()=>{loadInfo(); loadDash();}, 10000);
