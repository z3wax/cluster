@echo off
rem SDrive Cluster — Windows qurilish skripti
rem Talab: MinGW-w64 (g++ 9+) yoki MSVC
if not exist build mkdir build
cd build
cmake .. -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release
mingw32-make -j%NUMBER_OF_PROCESSORS%
if exist sdrive.exe (
  echo.
  echo [OK] sdrive.exe tayyor — ../../backend/sdrive-server.exe bilan ishga tushiring
)
